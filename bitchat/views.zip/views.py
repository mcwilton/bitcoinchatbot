from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from twilio.twiml.messaging_response import MessagingResponse
from datetime import datetime
import math
import emoji
import re
import ccxt
import cryptocompare
from forex_python.bitcoin import BtcConverter
from forex_python.converter import CurrencyRates

bitmex = ccxt.bitmex()
kraken = ccxt.kraken()
bittrex = ccxt.bittrex()

bitmex_price = bitmex.fetch_ticker('BTC/USD')['close']
kraken_price = kraken.fetch_ticker('BTC/USD')['close']
bittrex_price = bittrex.fetch_ticker('BTC/USD')['close']

all_prices_loop = [bittrex_price, bitmex_price, kraken_price]

def hilow():
	highest_price = max(all_prices_loop)
	lowest_price = min(all_prices_loop)
	arbitrage = highest_price - lowest_price
	return f"Buy @ {lowest_price} and sell @ {highest_price}. Your arbitrage gain is {arbitrage} "

@csrf_exempt
def index(request):
	if request.method == 'POST':

		incoming_msg = request.POST['Body'].lower()
		message = incoming_msg.split()

		resp = MessagingResponse()
		msg = resp.message()
		responded = False

		if incoming_msg == 'hi':
			reply = emoji.emojize("""
Welcome to BitBot for everything Bitcoin""",
use_aliases = True)
			msg.Body = (reply)
			responded = True





